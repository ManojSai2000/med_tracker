Med Tracker

This Smart Hospital System is an innovative digital platform designed to transform hospital operations. This comprehensive system enhances patient care and optimizes management processes by providing real-time access to essential information for all stakeholders - patients, doctors, and administrators.
